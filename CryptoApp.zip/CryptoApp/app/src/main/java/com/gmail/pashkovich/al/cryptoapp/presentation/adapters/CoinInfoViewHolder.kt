package com.gmail.pashkovich.al.cryptoapp.presentation.adapters

import androidx.recyclerview.widget.RecyclerView
import com.gmail.pashkovich.al.cryptoapp.databinding.ItemCoinInfoBinding

class CoinInfoViewHolder(val binding: ItemCoinInfoBinding) :
    RecyclerView.ViewHolder(binding.root) {
}